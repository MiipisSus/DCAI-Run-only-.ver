# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 5.15.2
# WARNING! All changes made in this file will be lost!

from PySide2 import QtCore

qt_resource_data = b"\
\x00\x00\x01\xb4\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x221\
6\x22 width=\x2210\x22 vi\
ewBox=\x220 0 320 5\
12\x22><!--!Font Aw\
esome Free 6.5.1\
 by @fontawesome\
 - https://fonta\
wesome.com Licen\
se - https://fon\
tawesome.com/lic\
ense/free Copyri\
ght 2024 Fontico\
ns, Inc.--><path\
 opacity=\x221\x22 fil\
l=\x22#1E3050\x22 d=\x22M\
182.6 137.4c-12.\
5-12.5-32.8-12.5\
-45.3 0l-128 128\
c-9.2 9.2-11.9 2\
2.9-6.9 34.9s16.\
6 19.8 29.6 19.8\
H288c12.9 0 24.6\
-7.8 29.6-19.8s2\
.2-25.7-6.9-34.9\
l-128-128z\x22/></s\
vg>\
\x00\x00\x02\x85\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x221\
6\x22 width=\x2210\x22 vi\
ewBox=\x220 0 320 5\
12\x22><!--!Font Aw\
esome Free 6.5.1\
 by @fontawesome\
 - https://fonta\
wesome.com Licen\
se - https://fon\
tawesome.com/lic\
ense/free Copyri\
ght 2024 Fontico\
ns, Inc.--><path\
 opacity=\x221\x22 fil\
l=\x22#1E3050\x22 d=\x22M\
80 160c0-35.3 28\
.7-64 64-64h32c3\
5.3 0 64 28.7 64\
 64v3.6c0 21.8-1\
1.1 42.1-29.4 53\
.8l-42.2 27.1c-2\
5.2 16.2-40.4 44\
.1-40.4 74V320c0\
 17.7 14.3 32 32\
 32s32-14.3 32-3\
2v-1.4c0-8.2 4.2\
-15.8 11-20.2l42\
.2-27.1c36.6-23.\
6 58.8-64.1 58.8\
-107.7V160c0-70.\
7-57.3-128-128-1\
28H144C73.3 32 1\
6 89.3 16 160c0 \
17.7 14.3 32 32 \
32s32-14.3 32-32\
zm80 320a40 40 0\
 1 0 0-80 40 40 \
0 1 0 0 80z\x22/></\
svg>\
\x00\x00\x01\xb6\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x221\
6\x22 width=\x2210\x22 vi\
ewBox=\x220 0 320 5\
12\x22><!--!Font Aw\
esome Free 6.5.1\
 by @fontawesome\
 - https://fonta\
wesome.com Licen\
se - https://fon\
tawesome.com/lic\
ense/free Copyri\
ght 2024 Fontico\
ns, Inc.--><path\
 opacity=\x221\x22 fil\
l=\x22#1E3050\x22 d=\x22M\
137.4 374.6c12.5\
 12.5 32.8 12.5 \
45.3 0l128-128c9\
.2-9.2 11.9-22.9\
 6.9-34.9s-16.6-\
19.8-29.6-19.8L3\
2 192c-12.9 0-24\
.6 7.8-29.6 19.8\
s-2.2 25.7 6.9 3\
4.9l128 128z\x22/><\
/svg>\
\x00\x00\x02\xc0\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x221\
6\x22 width=\x2216\x22 vi\
ewBox=\x220 0 512 5\
12\x22><!--!Font Aw\
esome Free 6.5.1\
 by @fontawesome\
 - https://fonta\
wesome.com Licen\
se - https://fon\
tawesome.com/lic\
ense/free Copyri\
ght 2024 Fontico\
ns, Inc.--><path\
 opacity=\x221\x22 fil\
l=\x22#1E3050\x22 d=\x22M\
512 256c0 .9 0 1\
.8 0 2.7c-.4 36.\
5-33.6 61.3-70.1\
 61.3H344c-26.5 \
0-48 21.5-48 48c\
0 3.4 .4 6.7 1 9\
.9c2.1 10.2 6.5 \
20 10.8 29.9c6.1\
 13.8 12.1 27.5 \
12.1 42c0 31.8-2\
1.6 60.7-53.4 62\
c-3.5 .1-7 .2-10\
.6 .2C114.6 512 \
0 397.4 0 256S11\
4.6 0 256 0S512 \
114.6 512 256zM1\
28 288a32 32 0 1\
 0 -64 0 32 32 0\
 1 0 64 0zm0-96a\
32 32 0 1 0 0-64\
 32 32 0 1 0 0 6\
4zM288 96a32 32 \
0 1 0 -64 0 32 3\
2 0 1 0 64 0zm96\
 96a32 32 0 1 0 \
0-64 32 32 0 1 0\
 0 64z\x22/></svg>\
\x00\x00\x02\x11\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x221\
6\x22 width=\x2214\x22 vi\
ewBox=\x220 0 448 5\
12\x22><!--!Font Aw\
esome Free 6.5.1\
 by @fontawesome\
 - https://fonta\
wesome.com Licen\
se - https://fon\
tawesome.com/lic\
ense/free Copyri\
ght 2024 Fontico\
ns, Inc.--><path\
 opacity=\x221\x22 fil\
l=\x22#1E3050\x22 d=\x22M\
64 32C28.7 32 0 \
60.7 0 96V416c0 \
35.3 28.7 64 64 \
64H384c35.3 0 64\
-28.7 64-64V96c0\
-35.3-28.7-64-64\
-64H64zM337 209L\
209 337c-9.4 9.4\
-24.6 9.4-33.9 0\
l-64-64c-9.4-9.4\
-9.4-24.6 0-33.9\
s24.6-9.4 33.9 0\
l47 47L303 175c9\
.4-9.4 24.6-9.4 \
33.9 0s9.4 24.6 \
0 33.9z\x22/></svg>\
\
\x00\x00\x01\xe4\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x221\
6\x22 width=\x2214\x22 vi\
ewBox=\x220 0 448 5\
12\x22><!--!Font Aw\
esome Free 6.5.1\
 by @fontawesome\
 - https://fonta\
wesome.com Licen\
se - https://fon\
tawesome.com/lic\
ense/free Copyri\
ght 2024 Fontico\
ns, Inc.--><path\
 opacity=\x221\x22 fil\
l=\x22#1E3050\x22 d=\x22M\
384 80c8.8 0 16 \
7.2 16 16V416c0 \
8.8-7.2 16-16 16\
H64c-8.8 0-16-7.\
2-16-16V96c0-8.8\
 7.2-16 16-16H38\
4zM64 32C28.7 32\
 0 60.7 0 96V416\
c0 35.3 28.7 64 \
64 64H384c35.3 0\
 64-28.7 64-64V9\
6c0-35.3-28.7-64\
-64-64H64z\x22/></s\
vg>\
\x00\x00\x02\x17\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 height=\x221\
6\x22 width=\x2214\x22 vi\
ewBox=\x220 0 448 5\
12\x22><!--!Font Aw\
esome Free 6.5.1\
 by @fontawesome\
 - https://fonta\
wesome.com Licen\
se - https://fon\
tawesome.com/lic\
ense/free Copyri\
ght 2024 Fontico\
ns, Inc.--><path\
 opacity=\x221\x22 fil\
l=\x22#1E3050\x22 d=\x22M\
135.2 17.7L128 3\
2H32C14.3 32 0 4\
6.3 0 64S14.3 96\
 32 96H416c17.7 \
0 32-14.3 32-32s\
-14.3-32-32-32H3\
20l-7.2-14.3C307\
.4 6.8 296.3 0 2\
84.2 0H163.8c-12\
.1 0-23.2 6.8-28\
.6 17.7zM416 128\
H32L53.2 467c1.6\
 25.3 22.6 45 47\
.9 45H346.9c25.3\
 0 46.3-19.7 47.\
9-45L416 128z\x22/>\
</svg>\
\x00\x00\x01\x9c\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 viewBox=\x22\
0 0 448 512\x22><!-\
-!Font Awesome F\
ree 6.5.1 by @fo\
ntawesome - http\
s://fontawesome.\
com License - ht\
tps://fontawesom\
e.com/license/fr\
ee Copyright 202\
4 Fonticons, Inc\
.--><path d=\x22M25\
6 80c0-17.7-14.3\
-32-32-32s-32 14\
.3-32 32V224H48c\
-17.7 0-32 14.3-\
32 32s14.3 32 32\
 32H192V432c0 17\
.7 14.3 32 32 32\
s32-14.3 32-32V2\
88H400c17.7 0 32\
-14.3 32-32s-14.\
3-32-32-32H256V8\
0z\x22/></svg>\
"

qt_resource_name = b"\
\x00\x06\
\x07\x03}\xc3\
\x00i\
\x00m\x00a\x00g\x00e\x00s\
\x00\x0c\
\x06\xe6\xeb\xe7\
\x00u\
\x00p\x00_\x00a\x00r\x00r\x00o\x00w\x00.\x00s\x00v\x00g\
\x00\x12\
\x01\xd9\x06g\
\x00H\
\x00i\x00n\x00t\x00P\x00u\x00s\x00h\x00B\x00u\x00t\x00t\x00o\x00n\x00.\x00s\x00v\
\x00g\
\x00\x0e\
\x04\xa2\xf1'\
\x00d\
\x00o\x00w\x00n\x00_\x00a\x00r\x00r\x00o\x00w\x00.\x00s\x00v\x00g\
\x00\x19\
\x05f\xb4'\
\x00c\
\x00h\x00o\x00o\x00s\x00e\x00C\x00o\x00l\x00o\x00r\x00P\x00u\x00s\x00h\x00B\x00u\
\x00t\x00t\x00o\x00n\x00.\x00s\x00v\x00g\
\x00\x14\
\x07\xe3\x5cG\
\x00c\
\x00h\x00e\x00c\x00k\x00B\x00o\x00x\x00_\x00c\x00h\x00e\x00c\x00k\x00e\x00d\x00.\
\x00s\x00v\x00g\
\x00\x0c\
\x04V)'\
\x00c\
\x00h\x00e\x00c\x00k\x00B\x00o\x00x\x00.\x00s\x00v\x00g\
\x00\x14\
\x02\xea\xff'\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00P\x00u\x00s\x00h\x00B\x00u\x00t\x00t\x00o\x00n\x00.\
\x00s\x00v\x00g\
\x00\x0d\
\x040b'\
\x00a\
\x00d\x00d\x00B\x00u\x00t\x00t\x00o\x00n\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x08\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x000\x00\x00\x00\x00\x00\x01\x00\x00\x01\xb8\
\x00\x00\x01\x8c\xf7\xcd$\x19\
\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00\x0c\xbc\
\x00\x00\x01\x8c\xf7\xcd$\x19\
\x00\x00\x01.\x00\x00\x00\x00\x00\x01\x00\x00\x0e\xd7\
\x00\x00\x01\x8d\xbe\xf8\xc4]\
\x00\x00\x00\xe2\x00\x00\x00\x00\x00\x01\x00\x00\x0a\xd4\
\x00\x00\x01\x8c\xf7\xcd$\x19\
\x00\x00\x00Z\x00\x00\x00\x00\x00\x01\x00\x00\x04A\
\x00\x00\x01\x8c\xf7\xcd$\x1d\
\x00\x00\x00|\x00\x00\x00\x00\x00\x01\x00\x00\x05\xfb\
\x00\x00\x01\x8c\xf7\xcd$\x19\
\x00\x00\x00\x12\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x8c\xf7\xcd$\x1d\
\x00\x00\x00\xb4\x00\x00\x00\x00\x00\x01\x00\x00\x08\xbf\
\x00\x00\x01\x8c\xf7\xcd$\x19\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
